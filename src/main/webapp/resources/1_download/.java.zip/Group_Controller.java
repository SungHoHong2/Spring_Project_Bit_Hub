
package bitplace.controller;
fff
fff

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import bitplace.dao.Bit_Rep;
import bitplace.vo.Bean;

import com.jcabi.github.Commits;
import com.jcabi.github.Coordinates;
import com.jcabi.github.Github;
import com.jcabi.github.Repo;
import com.jcabi.github.RepoCommit;
import com.jcabi.github.RepoCommits;
import com.jcabi.github.RtGithub;
import com.jcabi.http.response.JsonResponse;
import com.jcabi.immutable.ArrayMap;

@Controller
@RequestMapping("ajax/groups/{service}")
public class Group_Controller{	

	@Autowired
	Bit_Rep repository;

	Github github;
	Repo repo;
	Bean bean;

	@ModelAttribute("ajax_data")
	public Object data(HttpServletRequest request, 
			          HttpSession session,
					  @PathVariable("service")String service
					  ){
		Object res = null;
		bean = new Bean();
		//sends group number to the body 			
		res = request.getParameter("groupNo");		

		switch(service){
		case "insertGroup" : 
			System.out.println("InsertGroup Activated");
			System.out.println(request.getParameter("groupname"));
			System.out.println(request.getParameter("code"));
			break;

		case "displayContent" :			
			bean.setGit_repository(request.getParameter("git_rep"));
			bean.setGit_id(request.getParameter("git_id"));
			bean.setGit_pwd(request.getParameter("git_pwd"));
			bean.setContentno(Integer.parseInt(request.getParameter("contentno")));

			session.setAttribute("current_git_id", bean);
			github = new RtGithub(bean.getGit_id(),bean.getGit_pwd());				

			repo = github.repos().get(
					new Coordinates.Simple(bean.getGit_id(),bean.getGit_repository())
					);	
			
			res = repository.getContent(bean.getContentno());
			break;

		case "content_commitinfo_all":
			//			RepoCommits commits = repo.commits();
			//			Iterator iterator = commits.iterate(new ArrayMap()
			//					/*.with("since","2014-01-26T00:00:00Z")
			//						.with("until","2014-10-27T00:00:00Z")*/).iterator();
			//			ArrayList shas_commits = new ArrayList();
			//
			//			while(iterator.hasNext()){
			//				shas_commits.add(iterator.next().sha());
			//			}
			//			JsonObject tree_of_commit=null;
			//			String sha_of_tree = null;
			//
			//			ArrayList shas_trees = new ArrayList();
			//			Commits commits1 = repo.git().commits();
			//			for(String commit_string : shas_commits){
			//				try {
			//					tree_of_commit = commits1.get(commit_string).json().getJsonObject("tree");
			//					sha_of_tree  = tree_of_commit.getString("sha");
			//					shas_trees.add(sha_of_tree);
			//				} catch (IOException e) {
			//					// TODO Auto-generated catch block
			//					e.printStackTrace();
			//				}
			//			}	
			//			res = shas_trees;
			//			break;

		case "content_commitinfo":
			Bean bean = (Bean) session.getAttribute("current_git_id");			
			ArrayList shas_trees = new ArrayList();
			String sha_of_tree = null;
			JsonResponse resp = null;
			
			try {
				resp = new RtGithub().entry()
						.uri().path("/repos/" +bean.getGit_id()+"/" + bean.getGit_repository()+"/commits")
										.back()
										.fetch()
										.as(JsonResponse.class);
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			sha_of_tree = resp.json().readArray().getJsonObject(0).getJsonObject("commit").getJsonObject("tree").getString("sha");
			shas_trees.add(sha_of_tree);
			res = shas_trees;
			break;


		case "content_commitinfo_search1" :	
			ArrayList list = new ArrayList();
			Bean bean2;
			try {
				JsonArray value = repo.git().trees().get(request.getParameter("sha")).json().getJsonArray("tree");
				JsonObject value_jsonObject = null;

				for(int i=0; i